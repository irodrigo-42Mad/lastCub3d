/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_set_raycast.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/07/08 10:42:41 by irodrigo          #+#    #+#             */
/*   Updated: 2021/01/10 17:20:13 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./cub3d.h"

/*pendiente*/
void	raycauxtwo(t_game_draw *mygame)
{
	if (mygame->side == 0 && mygame->raydir.x > 0)
		mygame->id = 3;
	if (mygame->side == 0 && mygame->raydir.x <= 0)
		mygame->id = 2;
	if (mygame->side == 1 && mygame->raydir.y > 0)
		mygame->id = 4;
	if (mygame->side == 1 && mygame->raydir.y <= 0)
		mygame->id = 0;
}

void	raycasting(t_game_draw *mygame)
{
	mygame->col = 0;
	mygame->img = mlx_new_image(mygame->mlx_ptr, mygame->win.x, mygame->win.y);
	mygame->img_ptr = mlx_get_data_addr(mygame->img, &mygame->bpp, &mygame->sl,
		&mygame->endian);
	while (mygame->col < mygame->win.x)
	{
		mygame->camerax = 2 * mygame->col / (double)(mygame->win.x) - 1;
		mygame->raydir.x = mygame->dir.x + mygame->plane.x * mygame->camerax;
		mygame->raydir.y = mygame->dir.y + mygame->plane.y * mygame->camerax;
		mygame->map.x = (int)mygame->pos.x;
		mygame->map.y = (int)mygame->pos.y;
		mygame->deltadist.x = fabs((1 / mygame->raydir.x));
		mygame->deltadist.y = fabs((1 / mygame->raydir.y));

		mygame->hit = 0;
		ft_calc_step(mygame);

		mygame->zbuffer[mygame->col] = mygame->perpwalldist;
	}
	to_img(mygame);
	/*if (mygame->obj == 1)
		//draw_sprite(mygame);
	to_img(mygame);*/
}

void	ft_calc_step(t_game_draw *mygame)
{
	if (mygame->raydir.x < 0)
	{
		mygame->step.x = -1;
		mygame->sidedist.x = (mygame->pos.x - mygame->map.x)
		* mygame->deltadist.x;
	}
	else
	{
		mygame->step.x = 1;
		mygame->sidedist.x = (mygame->map.x + 1.0 - mygame->pos.x)
		* mygame->deltadist.x;
	}
	if (mygame->raydir.y < 0)
	{
		mygame->step.y = -1;
		mygame->sidedist.y = (mygame->pos.y - mygame->map.y)
		* mygame->deltadist.y;
	}
	else
	{
		mygame->step.y = 1;
		mygame->sidedist.y = (mygame->map.y + 1.0 - mygame->pos.y)
		* mygame->deltadist.y;
	}
	ft_perf_dda(mygame);
}

void	ft_perf_dda(t_game_draw *mygame)
{
	while (mygame->hit == 0)
	{
		if (mygame->sidedist.x < mygame->sidedist.y)
		{
			mygame->sidedist.x += mygame->deltadist.x;
			mygame->map.x += mygame->step.x;
			mygame->side = 0;
		}
		else
		{
			mygame->sidedist.y += mygame->deltadist.y;
			mygame->map.y = mygame->step.y;
			mygame->side = 1;
		}
		if (mygame->worldmap[mygame->map.x][mygame->map.y] != '0')
			mygame->hit = 1;
	}
	ft_perp_dist(mygame);
}

void	ft_perp_dist(t_game_draw *mygame)
{
	if (mygame->side == 0)
		mygame->perpwalldist = (mygame->map.x - mygame->pos.x +
		(1 - mygame->step.x) / 2) / mygame->raydir.x;
	else
		mygame->perpwalldist = (mygame->map.y - mygame->pos.y +
			(1 - mygame->step.y) / 2) / mygame->raydir.y;
	mygame->lineheight = (int)(mygame->win.y / mygame->perpwalldist);
	mygame->drawstart = -mygame->lineheight / 2 + mygame->win.y / 2;
	if (mygame->drawstart < 0)
		mygame->drawstart = 0;
	mygame->drawend = mygame->lineheight / 2 + mygame->win.y / 2;
	if (mygame->drawend >= mygame->win.y)
		mygame->drawend = mygame->win.y - 1;
	raycauxtwo(mygame);
	auxline(mygame);
	ft_verline(mygame);
	mygame->col++;
}
