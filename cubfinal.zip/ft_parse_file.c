/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_file.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/04/11 02:35:13 by irodrigo          #+#    #+#             */
/*   Updated: 2021/01/11 16:29:36 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./cub3d.h"

static int		ft_resolution(t_game_draw *mygame, char *line, int *pos)
{
	if (mygame->win.x != 0 || mygame->win.y != 0)
		return (-3);
	(*pos)++;
	mygame->win.x = ft_atoi_cub(line, pos);
	mygame->win.y = ft_atoi_cub(line, pos);
	if (mygame->win.x > MAXWIDTH)
		mygame->win.x = MAXWIDTH;
	if (mygame->win.y > MAXHEIGHT)
		mygame->win.y = MAXHEIGHT;
	ft_skip_spaces(line, pos);
	if (mygame->win.x <= 0 || mygame->win.y <= 0 || line[*pos] != '\0')
		return (-4);
	return (0);
}

static char		*getstr(char *temp)
{
	while (*temp != '.')
		temp++;
	return (temp);
}

static int		getcolor(unsigned int *color, char *line, int *pos)
{
	int	r;
	int	g;
	int	b;

	if (*color != RGB_NONE)
		return (-5);
	(*pos)++;
	r = ft_atoi_cub(line, pos);
	(*pos)++;
	g = ft_atoi_cub(line, pos);
	(*pos)++;
	b = ft_atoi_cub(line, pos);
	ft_skip_spaces(line, pos);
	if (line[*pos] != '\0' || r > 255 || g > 255 || b > 255)
		return (-6);
	*color = r * 256 * 256 + g * 256 + b;
	return (0);
}

static int		takeline(t_game_draw *mygame, char *temp, char *line)
{
	char *temp2;

	temp = ft_strjoin(line, "\n");
	temp2 = mygame->mapchar;
	mygame->mapchar = ft_strjoin(mygame->mapchar, temp);
	free(temp2);
}

/*
**free(temp); // pendiente de probar posibles leaks
*/

int				get_info(t_game_draw *mygame, char *line)
{
	int		pos;

	pos = 0;
	ft_skip_spaces(line, &pos);
	if (line[0] == 'R' && line[1] == ' ')
		mygame->n_err = ft_resolution(mygame, line, &pos);
	else if (line[0] == 'N' && line[1] == 'O' && line[2] == ' ')
		mygame->n_err = ft_chk_texture(mygame, line, &pos, &mygame->maptx.no, 3);
	else if (line[0] == 'S' && line[1] == 'O' && line[2] == ' ')
		mygame->n_err = ft_chk_texture(mygame, line, &pos, &mygame->maptx.so, 2);
	else if (line[0] == 'W' && line[1] == 'E' && line[2] == ' ')
		mygame->n_err = ft_chk_texture(mygame, line, &pos, &mygame->maptx.we, 0);
	else if (line[0] == 'E' && line[1] == 'A' && line[2] == ' ')
		mygame->n_err = ft_chk_texture(mygame, line, &pos, &mygame->maptx.ea, 4);
	else if (line[0] == 'S' && line[1] == ' ')
		mygame->n_err = ft_chk_texture(mygame, line, &pos, &mygame->maptx.s, 5);
	else if (line[0] == 'F' && line[1] == ' ')
		mygame->n_err = getcolor(&mygame->maptx.c, line, &pos);
	else if (line[0] == 'C' && line[1] == ' ')
		mygame->n_err = getcolor(&mygame->maptx.f, line, &pos);
	else if ((line[pos] == '1' || mygame->n_err == 1) && line[pos] != '\0')
		takeline(mygame, pos, line);     // revision desde aqui....
	/*if (ft_skip_spaces(line, &pos) && mygame->n_err == 0 && line[pos] != '\0')
		return (error(-10));
	return (mygame->n_err < 0 ? error(mygame->n_err) : 0);*/
}
