/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/07/08 11:23:47 by jdiaz-co          #+#    #+#             */
/*   Updated: 2021/01/11 12:36:53 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _CUB3D_H
# define _CUB3D_H

# ifdef __linux__
# define KEY_A 97
# define KEY_W 119
# define KEY_S 115
# define KEY_D 100
# define KEY_UP 65362
# define KEY_LEFT 65361
# define KEY_RIGHT 65363
# define KEY_DOWN 65364
# define KEY_ESC 65307
# define KEY_SHIFT 65507
# include <X11/Xlib.h>
# include "./minilibx_linux/mlx.h"
# endif


# include "./libft/libft.h"
# include "./colors.h"
# include <unistd.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <fcntl.h>
# include <stdio.h>


# ifdef __APPLE__
# define KEY_A 0
# define KEY_S 1
# define KEY_D 2
# define KEY_W 13
# define KEY_UP 126
# define KEY_LEFT 123
# define KEY_RIGHT 124
# define KEY_DOWN 125
# define KEY_ESC 53
# define KEY_SHIFT 257
# include "./mlx_ios/mlx.h"//"./mlx_ios/mlx.h"
#endif

# define BUFFER_SIZE 1
# define MAXWIDTH 1920      //ojo res maxima linux
# define MAXHEIGHT 1080     //ojo res maxima linux

/*
**window control structures
*/
typedef struct  	s_syswin
{
     void        	*mlx_ptr;
     void        	*mlx_win;
}               	t_syswin;

typedef struct		s_resol
{
	int				h;
	int				w;
}					t_resol;

/*
**Drawing point structures
*/
typedef struct		s_dpoint
{
	double			x;
	double			y;
}					t_dpoint;

typedef struct		s_ipoint
{
	int				x;
	int				y;
}					t_ipoint;

/*
**texture structure
*/
typedef struct 		s_textures
{
	unsigned int	*no;  //revisar
	unsigned int	*so;  //revisar
	unsigned int	*we;  //revisar
	unsigned int	*ea;  //revisar
	unsigned int	*s;   //revisar
	unsigned int	f;
	unsigned int	c;
}					t_textures;

/*
**Color structure
*/
typedef struct		s_color
{
	int				r;
	int				g;
	int				b;
	int				alpha;
}					t_color;


/*
**Sprite definition and usage
*/
typedef struct		s_sprite
{
	t_resol			spr_dimens;
	t_dpoint		spr_pos;
	t_dpoint		sp_act_pos;
	t_dpoint		transform;
	t_ipoint		spr_initial;
	t_ipoint		spr_texture;
	t_ipoint		spr_trace;
	int				scrn;
}					t_sprite;

/*
**Keyboard control structures
*/
 typedef struct		s_key_ctrl
{	int 			a_status;
	int 			d_status;
 	int 			esc_status;
 	int				s_status;
 	int				w_status;
 	int				lf_status;
 	int				rg_status;
 	int				up_status;
 	int				dw_status;
 	int				sh_status;
 }					t_key_ctrl;

/*
**bmp image format header
*/
typedef struct      s_bmp_hdr{
	unsigned int    f_size;
	unsigned char   rsvd_1;
	unsigned char   rsvd_2;
	unsigned int    offs_bts;
	unsigned int    sz_headr;
	t_resol         dimens;
	short int       planes;
	short int       bt_count;
	unsigned int    compress;
	unsigned int    img_bt_size;
	unsigned int    ppm_x;
	unsigned int    ppm_y;
	unsigned int    clr_used;
	unsigned int    clr_importnt;
}                   t_bmp_hdr;

/*
**Principal game control structure
*/
typedef struct		s_game_draw     //map
{
	char			*mapchar;   //tmp_map;
	char			**worldmap;

	double			camerax;  	// camera
	int				hit;	  	// hit
	int				side;  		// side;
	t_dpoint		raydir;	  	//raydirx 		// raydiry
	t_dpoint		dir;      	// dirx    		// diry
	t_dpoint		deltadist;	//deltadistx  	// deltadisty
	t_dpoint		sidedist; 	//sidedistx		// sidedisty
	double			perpwalldist;
	t_ipoint		gamer;




	t_textures		maptx;




	void        	*mlx_ptr;
    void        	*mlx_win;
	t_resol			screen;   // height  	// width
	char			p_dir;	  // dir
	int				idx_pos;  // pos
	t_dpoint		pos;	  // posx		// posy


	t_dpoint		plane;	  //planex		// planey




	t_ipoint		step;	  //stepx		// stepy
	t_ipoint		map;	  //mapx		// mapy
	t_ipoint		fr_pos;	  //fpposx		// fpposy
	t_ipoint		win;	  //winx		// winy
	t_ipoint		mtx;	  //x			// y


	t_sprite		*sprite;
	int				*allspr_pos;	//spriteorder;
	double			*allspr_dist;	//spritedistance;
	double			my_speed;		//movespeed;
	double			my_rotspeed;	//rotspeed;
	int				spr_total;		//spr_total;

	t_key_ctrl		key;			//all_status

	int				segment;     	//stripe;
	int				el_count;	 	//count;
	int				aux_elcount; 	//countb;

	//int				initialdir;
	int				screenshot; //veremos a ver

	int				n;			//cambiar nombre
	char			*wlone[8];  //wallone
	char			*wdata[8];	//walldata
	int				wbpp[8]; 	//wallbpp
	int				wendian[8];
	int				wsl[8];

	//t_resol				size;
	int				height[8];  //h[8];
	int				width[8];	//w[8];

	int				col;

	int				lineheight;
	int				drawstart;
	int				drawend;
	int				color;
	int				j;

	void			**img;
	char			*img_ptr;

	int				id;
	double			x_wall;  // wall_x
	int				x_text;  //x_texture
	int				y_text;	 //y_texture
	int				tex_pos; // aux for position y of texture
	double			tex_stp; // pasos de la textura

	int				bpp;
	int				sl;
	int				endian;
	int				alturalinea;
	double			oldplanex;
	double			olddirx;
	double			zbuffer[4000];
	int				obj;

	int				n_err;
	int				map_err;

	t_color			el_color;

	int				r;
	int				g;
	int				b;
}					t_game_draw;

int					gamename(char **argv);
int					parsename(char **argv);
int					ft_texture_check (char *name);
void				read_file(int argc, char **file_name, t_game_draw *mygame);
int					get_next_line(int fd, char **line);
int					get_info(t_game_draw *mygame, char *line);
int					ft_chk_texture(t_game_draw *mygame, char *line, int *pos, unsigned int **path, int elm);
int					wall_texture(t_game_draw *mygame, char *path, unsigned int **elmt, int elm);
int             	ft_getpixel(t_game_draw *map, int x, int y);
void            	ft_mlx_pixel_put(t_game_draw *mygame, int x, int y, int color);

void				read_map(t_game_draw *mygame);
void				matrix(t_game_draw *mygame);
//void				stringtoarray(t_game_draw *mygame);
void				skiptab(t_game_draw *mygame);
int					get_width(char *str);
int					get_height(char *str);
void				initvar(t_game_draw *mygame);
int					checkmap(t_game_draw *mygame);
void				openall(t_game_draw *mygame);

void				more_texture(t_game_draw *mygame);
void				raycasting(t_game_draw *mygame);
void				ft_calc_step(t_game_draw *mygame);
void				ft_perf_dda(t_game_draw *mygame);
void				ft_perp_dist(t_game_draw *mygame);




//void				raycauxtwo(t_game_draw *mygame);
void				ft_verline(t_game_draw *mygame);
void				auxline(t_game_draw *mygame);
void				auxlinetwo(t_game_draw *mygame);
void				printhp(t_game_draw *mygame);
void				put_pxl_to_img(t_game_draw *mygame, int x, int y);
void				to_img(t_game_draw *mygame);
void				raycauxthree(t_game_draw *mygame);// mal
void				calcularobj(t_game_draw *mygame);
int					nopulsed(int key, t_game_draw *mygame);
int					pulsed(int key, t_game_draw *mygame);
int					deal_key(t_game_draw *mygame);
int					write_bmp_header(int fd, int filesize, t_game_draw *mygame); //rev
int					write_bmp_data(int file, t_game_draw *mygame, int pad);
int					ft_close(t_game_draw *mygame, int win); //segfault
void				draw_sprite(t_game_draw *mygame);
void				ft_swap_int(int *a, int *b);
void				ft_swap_double(double *a, double *b);
void				raysprite(t_game_draw *mygame);
void				spritepos(t_game_draw *mygame, int x, int y);
int					ft_atoi_color(char *line, int *i);
char				*ft_right(const char *mystr, int len);
int					ft_skip_spaces(char *line, int *i);
void 				prepare_line(char *line);
int					ft_atoi_cub(char *line, int *pos);
void 				ft_freearray(char **str);

void	checkborder(int x, int y, char **str, t_game_draw *err);

int    				error(int i);
#endif
