/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_keyboard.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/06/04 02:44:05 by irodrigo          #+#    #+#             */
/*   Updated: 2021/01/11 16:28:57 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./cub3d.h"

void	w_and_s(t_game_draw *mygame)
{
	if (mygame->key.w_status == 1)
	{
		if ((mygame->worldmap[(int)(mygame->pos.x + mygame->dir.x *
			(mygame->my_speed /*+ 0.6*/))][(int)mygame->pos.y]) != 1)
			mygame->pos.x += mygame->dir.x * mygame->my_speed;
		if ((mygame->worldmap[(int)mygame->pos.x][(int)(mygame->pos.y
			+ mygame->dir.y * (mygame->my_speed /*+ 0.6*/))]) != 1)
			mygame->pos.y += mygame->dir.y * mygame->my_speed;
	}

	if (mygame->key.s_status == 1)
	{
		if ((mygame->worldmap[(int)(mygame->pos.x - mygame->dir.x *
			(mygame->my_speed /*+ 0.6*/))][(int)mygame->pos.y]) != 1)
			mygame->pos.x -= mygame->dir.x * mygame->my_speed;
		if ((mygame->worldmap[(int)mygame->pos.x][(int)(mygame->pos.y -
			mygame->dir.y * (mygame->my_speed /*+ 0.6*/))]) != 1)
			mygame->pos.y -= mygame->dir.y * mygame->my_speed;
	}
}
/* pendiente */
void	a_and_d(t_game_draw *mygame)
{
	if (mygame->key.a_status == 1)
	{
		if ((mygame->worldmap[(int)(mygame->pos.x - mygame->dir.y *
			(mygame->my_speed /*+ 0.6*/))][(int)mygame->pos.y]) != 1)
			mygame->pos.x -= mygame->dir.y * mygame->my_speed;
		if ((mygame->worldmap[(int)mygame->pos.x][(int)(mygame->pos.y +
			mygame->dir.x * (mygame->my_speed /*+ 0.6*/))]) != 1)
			mygame->pos.y += mygame->dir.x * mygame->my_speed;
	}
	if (mygame->key.d_status == 1)
	{
		if ((mygame->worldmap[(int)(mygame->pos.x + mygame->dir.y *
			(mygame->my_speed /*+ 0.6*/))][(int)mygame->pos.y]) != 1)
			mygame->pos.x += mygame->dir.y * mygame->my_speed;
		if ((mygame->worldmap[(int)mygame->pos.x][(int)(mygame->pos.y -
			mygame->dir.x * (mygame->my_speed /*+ 0.6*/))]) != 1)
			mygame->pos.y -= mygame->dir.x * mygame->my_speed;
	}
}

void	l_and_r(t_game_draw *mygame)
{
	mygame->olddirx = mygame->dir.x;

	if (mygame->key.lf_status == 1)
	{
		mygame->dir.x = mygame->dir.x * cos(mygame->my_rotspeed)
			- mygame->dir.y * sin(mygame->my_rotspeed);
		mygame->dir.y = mygame->olddirx * sin(mygame->my_rotspeed) +
					mygame->dir.y * cos(mygame->my_rotspeed);
		mygame->oldplanex = mygame->plane.x;
		mygame->plane.x = mygame->plane.x * cos(-mygame->my_rotspeed)
			- mygame->plane.y * sin(mygame->my_rotspeed);
		mygame->plane.y = mygame->oldplanex * sin(mygame->my_rotspeed)
			+ mygame->plane.y * cos(-mygame->my_rotspeed);
	}
	if (mygame->key.rg_status == 1)
	{
		mygame->dir.x = mygame->dir.x * cos(-mygame->my_rotspeed)
			- mygame->dir.y * sin(-mygame->my_rotspeed);
		mygame->dir.y = mygame->olddirx * sin(-mygame->my_rotspeed) +
					mygame->dir.y * cos(-mygame->my_rotspeed);
		mygame->oldplanex = mygame->plane.x;
		mygame->plane.x = mygame->plane.x * cos(-mygame->my_rotspeed) -
			mygame->plane.y * sin(-mygame->my_rotspeed);
		mygame->plane.y = mygame->oldplanex * sin(-mygame->my_rotspeed)
			+ mygame->plane.y * cos(-mygame->my_rotspeed);
	}
}

int		ft_close(t_game_draw *mygame, int win)
{
	free(mygame->worldmap);
	free(mygame);
	if (win == 1)
		mlx_destroy_window(mygame->mlx_ptr, mygame->mlx_win);
	free(mygame->mlx_ptr);
	exit(0);
}

int		deal_key(t_game_draw *mygame)
{
	raycasting(mygame);
	w_and_s(mygame);
	a_and_d(mygame); //pendiente
	l_and_r(mygame);
	if (mygame->key.esc_status == 1)
		ft_close(mygame, 1);
	return (1);
}
