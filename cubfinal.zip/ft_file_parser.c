/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_file_parser.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/11 16:28:12 by irodrigo          #+#    #+#             */
/*   Updated: 2021/01/11 16:28:15 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int		ft_chk_texture(t_game_draw *mygame, char *line, int *pos, unsigned int **elms, int elm)
{
	char	*file;
	int		j;

	if (*elms != NULL)
		return (-7);
	(*pos) += 2;
	ft_skip_spaces(line, pos);
	j = *pos;
	while (line[*pos] != ' ' && line[*pos] != '\0')
		(*pos)++;
	if (!(file = malloc(sizeof(char) * (*pos - j + 1))))
		return (-8);
	*pos = j;
	j = 0;
	while (line[*pos] != ' ' && line[*pos] != '\0')
		file[j++] = line[(*pos)++];
	file[j] = '\0';
	j = wall_texture(mygame, file, elms, elm);
	free(file);
	return (j == -1 ? -9 : 0);
}
