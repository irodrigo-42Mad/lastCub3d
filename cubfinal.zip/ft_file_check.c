/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_file_check.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/11 16:27:52 by irodrigo          #+#    #+#             */
/*   Updated: 2021/01/11 16:27:57 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "cub3d.h"

int			gamename(char **argv)
{
	if (strcmp(ft_right(ft_strtrim(argv[0], "\n"), 7), "./cub3D") != 0)
		return(-1);
	return (1);
}

int			ft_texture_check (char *name)
{
	if (strcmp(ft_right(ft_strtrim(name, "\n"), 3), "xpm") != 0)
		return(-1);
	return (1);
}

void 		prepare_line(char *line)
{
	int i;
	int c;
	int auxp;
	char *aux;

	aux = (char *) malloc(ft_strlen(line) * 5);
	i = 0;
	auxp = 0;
	while(line[i] != '\0')
	{
		if(line[i] == '\t')
		{
			c = 0;
			while (c < 3)
			{
				aux[auxp] = ' ';
				auxp++;
				c++;
			}
		}
		else
		{
			aux[auxp] = line[i];
		}
		i++;
		auxp++;
	}
	aux[auxp] = '\0';
	strlcpy(line,aux,auxp);
}
