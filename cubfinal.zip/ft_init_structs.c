/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init_structs.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/07/08 09:44:20 by irodrigo          #+#    #+#             */
/*   Updated: 2021/01/11 16:25:07 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./cub3d.h"

void	initvar(t_game_draw *mygame)
{
	mygame->mlx_ptr = NULL;
	mygame->mlx_win = NULL;
	mygame->img = NULL;
	mygame->img_ptr = NULL;
	mygame->win.x = 0;
	mygame->win.y = 0;
	//mygame->screen.h = 0;
	//mygame->screen.w = 0;
	mygame->maptx.f = RGB_NONE;
	mygame->maptx.c = RGB_NONE;
	mygame->id = 0;
	mygame->my_speed = 0.12;
	mygame->my_rotspeed = 0.08;
	mygame->plane.x = 0;
	mygame->plane.y = 0;
	mygame->idx_pos = 0;
	mygame->dir.x = 0;
	mygame->dir.y = 0;
	mygame->sprite = NULL;
}

void	read_map(t_game_draw *mygame)
{
	mygame->screen.h = get_height(mygame->mapchar);
	mygame->screen.w = get_width(mygame->mapchar);

	skiptab(mygame);
	matrix(mygame);
}

void	read_file(int argc, char **file_name, t_game_draw *mygame)
{
	int		fd;
	char	*line;
	int		ret;

	ret = 1;
	mygame->mapchar = ft_strdup("");
	//comprobar la existencia del archivo antes de abrir
	if (!(fd = open(file_name[1], O_RDONLY, 0)))
	{
		error(8);
		close(fd);
		exit(0);
	}
	while (ret == 1)
	{
		ret = get_next_line(fd, &line);
		/*if (*/get_info(mygame, line);/*== -1)*/ //falta darle el retorno y controlar
		                                          //tabuladores
			//ret = -1;
		free(line);
	}
	close(fd);
	// revisar para quitar el ultimo leak
		/*system("leaks cub3D");*/
	if (argc == 3)
		mygame->screenshot = 1;
	if (argc == 3 && ft_strncmp(file_name[2], "--save", 6))
		exit(error(4) * -1);
}


/*
**	wall_texture(mygame);
*/

void	openall(t_game_draw *mygame)
{
	mygame->mlx_win = mlx_new_window(mygame->mlx_ptr, mygame->win.x,
		mygame->win.y, "cub3D 42");

	/*mygame->fr_pos.x = mygame->win.x / 2 - mygame->width[5] / 2;
	mygame->fr_pos.y = mygame->win.y - mygame->height[5];*/
	//raycasting(mygame);
	mlx_hook(mygame->mlx_win, 2, 1L << 0, nopulsed, mygame);
	mlx_hook(mygame->mlx_win, 3, 1L << 1, pulsed, mygame);
	mlx_hook(mygame->mlx_win, 17, 1L << 17, ft_close, mygame);
	mlx_loop_hook(mygame->mlx_ptr, deal_key, mygame);
	mlx_loop(mygame->mlx_ptr);
}
