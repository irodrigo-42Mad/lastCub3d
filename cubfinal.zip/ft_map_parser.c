/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map_parser.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/05/04 11:14:45 by irodrigo         #+#    #+#             */
/*   Updated: 2021/01/09 17:45:48 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./cub3d.h"

int			parsename(char **argv)
{
	if (strcmp(ft_right(ft_strtrim(argv[1], "\n"), 3), "cub") != 0)
		return (-1);
	return (1);
}

void	checkborder(int x, int y, char **str, t_game_draw *err)
{
    if (x == 0 || y == 0 || y == (ft_strlen(str[x])) || x == err->screen.h - 1
        || y >= ft_strlen(str[x + 1]) || y >= ft_strlen(str[x - 1]))
    {
        ft_freearray(str);
		err->map_err = 6;
        error(err->map_err);
        exit(6);
    }
    str[x][y] = '3';
    if (str[x][y + 1] == '0' || str[x][y + 1] == '2'|| str[x][y + 1] == '9')
        checkborder(x, y + 1, str, err);
    if (str[x][y - 1] == '0' || str[x][y - 1] == '2'|| str[x][y - 1] == '9')
        checkborder(x, y - 1, str, err);
    if (str[x + 1][y] == '0' || str[x + 1][y] == '2'|| str[x + 1][y] == '9')
        checkborder(x + 1, y, str, err);
    if (str[x - 1][y] == '0' || str[x - 1][y] == '2'|| str[x - 1][y] == '9')
        checkborder(x - 1, y, str, err);
}

static void	getdirandpos(t_game_draw *mygame, int x, int y)
{
	mygame->idx_pos++;
	mygame->pos.x = x + 0.5;
	mygame->pos.y = y + 0.5;
	mygame->gamer.x = x;
	mygame->gamer.y = y;
	if (mygame->p_dir == 'N')
	{
		mygame->dir.x = -1;
		mygame->dir.y = 0;
		mygame->plane.x = 0;
		mygame->plane.y = 0.66;
	}
	if (mygame->p_dir == 'S')
	{
		mygame->dir.x = 1;
		mygame->dir.y = 0;
		mygame->plane.x = 0;
		mygame->plane.y = -0.66;
	}
	if (mygame->p_dir == 'W')
	{
		mygame->dir.x = 0;
		mygame->dir.y = -1;
		mygame->plane.x = -0.66;
		mygame->plane.y = 0;
	}
	if (mygame->p_dir == 'E')
	{
		mygame->dir.x = 0;
		mygame->dir.y = 1;
		mygame->plane.x = 0.66;
		mygame->plane.y = 0;
	}
}

static int	checkcontent(t_game_draw *mygame)
{
	int	i;
	int	j;

	i = 0;
	while (i < mygame->screen.h)
	{
		j = 0;
		while (j < mygame->screen.w && !(mygame->worldmap[i][j]) == NULL)
		{
			mygame->worldmap[i][j] == '3' ? getdirandpos(mygame, i, j) : 0;
			mygame->worldmap[i][j] == '2' ? spritepos(mygame, i, j) : 0;
			if (((mygame->worldmap[i][j] == '0') || (mygame->worldmap[i][j] == '2')
			|| (mygame->worldmap[i][j] == '3'))
			&& ((mygame->worldmap[i - 1][j] == '9')
				|| (mygame->worldmap[i + 1][j] == '9') ||
				(mygame->worldmap[i][j - 1] == '9') ||
				(mygame->worldmap[i][j + 1] == '9')))
				return (-1);
			j++;
		}
		i++;
	}
	return (1);
}

static int checkimvalid_hwall(t_game_draw *mygame)
{
	int i;
	int j;
	int pos;
	int chkwall;

	i = 1;
	while (i < (mygame->screen.h - 1))
	{
		chkwall = 1;
		pos = 1;
		j = ft_strlen(mygame->worldmap[i]) - 2;
		while (pos < j && chkwall == 1)
		{
			if (mygame->worldmap[i][pos] == '0' ||
				mygame->worldmap[i][pos] == '2' ||
				mygame->worldmap[i][pos] == '9')
				chkwall = 0;
			pos++;
		}
		if (chkwall	== 1)
			return (-1);
		i++;
	}
	return (0);
}

static int checkimvalid_vwall(t_game_draw *mygame)
{
	int i;
	int j;
	int pos;
	int chkwall;

	i = 1;
	while (i < (mygame->screen.w - 1))
	{
		chkwall = 1;
		pos = 1;
		j = mygame->screen.h - 1;
		while (pos < j && chkwall == 1)
		{
			if (mygame->worldmap[pos][i] == '0' ||
				mygame->worldmap[pos][i] == '2' ||
				mygame->worldmap[pos][i] == '9')
				chkwall = 0;
			pos++;
		}
		if (chkwall	== 1)
			return (-1);
		i++;
	}
	return (0);
}

//gamer inside map
static int	gamerpos(t_game_draw *mygame)
{
	int i;
	int j;

	i = 0;  // fila 1
	while (mygame->worldmap[0][i])
	{
		if (mygame->worldmap[0][i] == '3')
			return (-1);
		i++;
	}
	i = 0;  // ultima fila
	while(mygame->worldmap[mygame->screen.h - 1][i])
	{
		if (mygame->worldmap[mygame->screen.h - 1][i] == '3')
			return (-1);
		i++;
	}
	i = 0;  // primera y ultima columna
	while (i < mygame->screen.h )
	{
		if (mygame->worldmap[i][0] == '3')
			return (-1);
		j = ft_strlen(mygame->worldmap[i]) - 1;
		if (mygame->worldmap[i][j] == '3')
			return (-1);
		i++;
	}
	return (0);
}

int			checkmap(t_game_draw *mygame)
{
	char **tmp;
	int i;
	int j;
	int pos;

	// hay que hacer aqui la asignacion de memoria de
	// la segunda estructura, cambiar la primera y
	// comprobar el resto para asignar cada elemento y
	// hacer la structura temporal.
	if (!(tmp =(char**)malloc(sizeof(char *) *  //ojo, es un char
			mygame->screen.h + 1)))
			return -1;
	i = 0;
	while (i < mygame->screen.h)
	{
		tmp[i] = ft_strdup(mygame->worldmap[i]);
		i++;
	}
	//chequea que los simbolos y jugador sean ok
	if (checkcontent(mygame) == -1)
		return (error(6));
	if (mygame->idx_pos > 1)
		return (error(5));
	if (mygame->idx_pos == 0)
		return (error(9));
	/*if (gamerpos(mygame) == -1)
		return (error(11));*/
	//chequeos de muros cerrados en el mapa
	/*if (checkimvalid_hwall(mygame) == -1)
		return (error(12));*/
/*	if (checkimvalid_vwall(mygame) == -1)
		return (error(13));*/
	tmp[mygame->gamer.x][mygame->gamer.y] = '0';
	//a partir de aqui ahora se realiza el chequeo de
	//mapa cerrado
	checkborder(mygame->gamer.x, mygame->gamer.y, tmp, mygame);
	i = 0;
	while (i < mygame->screen.h)
	{
		free(tmp[i]);
		tmp[i] = NULL;
		i++;
	}
	free(tmp);
	tmp = NULL;
	//chequeamos que estén todas las texturas
	if (mygame->maptx.no == NULL || mygame->maptx.so == NULL
		|| mygame->maptx.ea == NULL || mygame->maptx.we == NULL)
		return (-1);
	return (1);
}
