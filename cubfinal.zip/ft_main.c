/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/04/11 02:23:23 by irodrigo          #+#    #+#             */
/*   Updated: 2021/01/11 16:29:14 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./cub3d.h"

void	more_texture(t_game_draw *mygame)
{
	mygame->wlone[5] = mlx_xpm_file_to_image(mygame->mlx_ptr,
		"./textures/pistol.xpm", &mygame->width[5], &mygame->height[5]);
	mygame->wdata[5] = mlx_get_data_addr(mygame->wlone[5],
		&mygame->wbpp[5], &mygame->wsl[5], &mygame->wendian[5]);
	/*mygame->wlone[7] = mlx_xpm_file_to_image(mygame->mlx_ptr,
		mygame->s, &mygame->width[7], &mygame->height[7]);
	mygame->wdata[7] = mlx_get_data_addr(mygame->wlone[7],
		&mygame->wbpp[7], &mygame->wsl[7], &mygame->wendian[7]);
	free(mygame->we);
	free(mygame->so);
	free(mygame->ea);
	free(mygame->no);
	free(mygame->s);*/
}

int		wall_texture(t_game_draw *mygame, char *path, unsigned int **elmt, int elm)
{
	int		fd;
	void	*img;
	int		tab[5];

	if (ft_texture_check(path) == 0)
		return (-1);
	if ((fd = open(path, O_RDONLY)) == -1)
		return (-1);
	close(fd);
	mygame->wlone[elm] = mlx_xpm_file_to_image(mygame->mlx_ptr, path,
					&mygame->width[elm], &mygame->height[elm]);
	if (mygame->wlone[elm] == NULL /*|| tab[0] != 64 || tab[1] != 64*/) // revisar
		return (-1);
	mygame->wdata[elm] = mlx_get_data_addr(mygame->wlone[elm],
		&mygame->wbpp[elm], &mygame->wsl[elm], &mygame->wendian[elm]);


	img = mlx_xpm_file_to_image(mygame->mlx_ptr, path, &tab[0], &tab[1]);
	if (img == NULL || tab[0] != 64 || tab[1] != 64)
		return (-1);
	*elmt = (unsigned int *)mlx_get_data_addr(img, &tab[2], &tab[3], &tab[4]);
	free(img);
	return (0);
}



	/*mygame->wlone[0] = mlx_xpm_file_to_image(mygame->mlx_ptr, mygame->we,
					&mygame->width[0], &mygame->height[0]);
	mygame->wdata[0] = mlx_get_data_addr(mygame->wlone[0],
		&mygame->wbpp[0], &mygame->wsl[0], &mygame->wendian[0]);

	mygame->wlone[2] = mlx_xpm_file_to_image(mygame->mlx_ptr, mygame->so,
					&mygame->width[2], &mygame->height[2]);
	mygame->wdata[2] = mlx_get_data_addr(mygame->wlone[2],
		&mygame->wbpp[2], &mygame->wsl[2], &mygame->wendian[2]);
	mygame->wlone[3] = mlx_xpm_file_to_image(mygame->mlx_ptr, mygame->no,
					&mygame->width[3], &mygame->height[3]);
	mygame->wdata[3] = mlx_get_data_addr(mygame->wlone[3],
		&mygame->wbpp[3], &mygame->wsl[3], &mygame->wendian[3]);
	mygame->wlone[4] = mlx_xpm_file_to_image(mygame->mlx_ptr, mygame->ea,
					&mygame->width[4], &mygame->height[4]);
	mygame->wdata[4] = mlx_get_data_addr(mygame->wlone[4],
		&mygame->wbpp[4], &mygame->wsl[4], &mygame->wendian[4]);
	more_texture(mygame);
	write(1,"ok",1);
}*/

int		pulsed(int key, t_game_draw *mygame)
{
	if (key == KEY_W)
		mygame->key.w_status = 0;
	if (key == KEY_S)
		mygame->key.s_status = 0;
	if (key == KEY_A)
		mygame->key.a_status = 0;
	if (key == KEY_D)
		mygame->key.d_status = 0;
	if (key == KEY_UP)
		mygame->key.up_status = 0;
	if (key == KEY_LEFT)
		mygame->key.lf_status = 0;
	if (key == KEY_RIGHT)
		mygame->key.rg_status = 0;
	if (key == KEY_DOWN)
		mygame->key.dw_status = 0;
	if (key == KEY_ESC)
		mygame->key.esc_status = 0;
	if (key == KEY_SHIFT)
		mygame->my_speed = 0.12;
	return (0);
}

int		nopulsed(int key, t_game_draw *mygame)
{
	if (key == KEY_W)
		mygame->key.w_status = 1;
	if (key == KEY_S)
		mygame->key.s_status = 1;
	if (key == KEY_A)
		mygame->key.a_status = 1;
	if (key == KEY_D)
		mygame->key.d_status = 1;
	if (key == KEY_UP)
		mygame->key.up_status = 1;
	if (key == KEY_LEFT)
		mygame->key.lf_status = 1;
	if (key == KEY_RIGHT)
		mygame->key.rg_status = 1;
	if (key == KEY_DOWN)
		mygame->key.dw_status = 1;
	if (key == KEY_ESC)
		mygame->key.esc_status = 1;
	if (key == KEY_SHIFT)
		mygame->my_speed = 0.35;
	return (0);
}

int		main(int argc, char **argv)
{
	t_game_draw	*mygame;

	if (argc == 2 || argc == 3)
	{
		if (!(mygame = malloc(sizeof(t_game_draw))))
			return (error(3));
		/*if (gamename(argv) == -1)  //falta la funcion comprobar nombre juego
			return (error(10));*/
		if (parsename(argv) == -1)
			return (error(0));
		initvar(mygame);
		mygame->mlx_ptr = mlx_init();
		read_file(argc, argv, mygame); //revisar el error y salir
		read_map(mygame);
		if (checkmap(mygame) == -1)
		{
			return (error(1));
			exit(0);
		}
		free(mygame->mapchar);
		openall(mygame);
		return (0);
	}
	return (error(2));
}
