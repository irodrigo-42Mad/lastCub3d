/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_map.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/04/26 12:02:34 by irodrigo          #+#    #+#             */
/*   Updated: 2021/01/11 16:26:08 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./cub3d.h"

int			get_height(char *str)
{
	int	i;
	int	h;

	i = 0;
	h = 0;
	while (str[i] != '\0')
	{
		if (str[i] == '\n')
			h++;
		i++;
	}
	return (h);
}

int			get_width(char *str)
{
	int		w;
	int		i;
	int		temp;

	w = 0;
	i = 0;
	temp = 0;
	while (str[i] != '\0')
	{
		if (ft_isdigit(str[i]))
			temp++;
		if (str[i] == '\n')
		{
			if (temp > w)
				w = temp;
			temp = 0;
		}
		i++;
	}
	return (w);
}

void		skiptab(t_game_draw *mygame)
{
	int	i;

	i = 0;
	while (mygame->mapchar[i] != '\0')
	{
		if (mygame->mapchar[i] == '\t')
			mygame->mapchar[i] = '8';
		if (mygame->mapchar[i] == ' ')
			mygame->mapchar[i] = '9';
		if (mygame->mapchar[i] == 'N' || mygame->mapchar[i] == 'S'
			|| mygame->mapchar[i] == 'W' || mygame->mapchar[i] == 'E')
		{
			mygame->p_dir = mygame->mapchar[i];
			mygame->mapchar[i] = '3';
		}
		if (mygame->mapchar[i] == '2')
			mygame->spr_total++;
		i++;
	}
	mygame->sprite = malloc(mygame->spr_total * sizeof(t_sprite));
	//mygame->spr_total = 0;
}

/*void		stringtoarray(t_game_draw *mygame)
{
	if (mygame->mapchar[mygame->n] == '8')
	{
		// ver como se puede dejar esto más corto.
		mygame->worldmap[mygame->mtx.x][mygame->mtx.y++] = '9';
		mygame->worldmap[mygame->mtx.x][mygame->mtx.y++] = '9';
		mygame->worldmap[mygame->mtx.x][mygame->mtx.y++] = '9';
		mygame->worldmap[mygame->mtx.x][mygame->mtx.y] = '9';
	}
	else if (mygame->mapchar[mygame->n] == '9')
		mygame->worldmap[mygame->mtx.x][mygame->mtx.y] = '9';
	else if (mygame->mapchar[mygame->n] == '\n' || mygame->mapchar[mygame->n] == '\0')
	{
		while (mygame->mtx.y <= get_width(mygame->mapchar))
		{
			mygame->worldmap[mygame->mtx.x][mygame->mtx.y] = '9';
			mygame->mtx.y++;
		}
		mygame->n -= 1;
	}
	else
		mygame->worldmap[mygame->mtx.x][mygame->mtx.y] = mygame->mapchar[mygame->n] - 48;
	mygame->n++;
	mygame->mtx.y++;
}*/

void		matrix(t_game_draw *mygame)
{
	mygame->mtx.x = 0;
	mygame->n = 0;
	if (!mygame->worldmap)
		if (!(mygame->worldmap = (char **)malloc(sizeof(char *) *
			get_height(mygame->mapchar) + 1)))
			return ;
	mygame->worldmap = ft_split(mygame->mapchar, '\n');


/*

	while (mygame->mtx.x <= get_height(mygame->mapchar))
	{
		if (!(mygame->worldmap[mygame->mtx.x] = malloc(sizeof(int) *
			(get_width(mygame->mapchar) + 1))))
			return ;
		mygame->mtx.y = 0;
		while (mygame->mtx.y <= get_width(mygame->mapchar))
		{
			stringtoarray(mygame);
			//printf("%d \t",mygame->worldmap[mygame->mtx.x][mygame->mtx.y]);
		}
		mygame->n++;
		mygame->mtx.y = 0;
		mygame->mtx.x++;
	}*/
}
