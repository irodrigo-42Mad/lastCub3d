#include "cub3d.h"

static int parsename2 (const char *data, const char *compare)
{
	int len;

	len = ft_strlen (compare);
	if (strcmp(ft_right(ft_strtrim(data, "\n"), len), compare) != 0)
		return (-1);
	return (1);
}


int		main(int argc, char **argv)
{
	int status;

	if(parsename2(argv[0], "cub3D") == -1)
		printf("Error en el nombre del programa");

}

